﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mortgage_Calculator
{
    class Mortgage

    {

       public static string compound(string , string interestrate, string monthlydep, string yr, string timescomp)
            try
            {
                // variables to hold the values 

                double prinp = 0;              // original amount
                double downpay;           //  down payment 
                double loanamount;       //   amount loaned
                int loanlength;         //    length in loan (years)
                double interestrate;   //    the interest rate 



                // parse the values down, when the user inputs in the text boxes

                

            }       
}
